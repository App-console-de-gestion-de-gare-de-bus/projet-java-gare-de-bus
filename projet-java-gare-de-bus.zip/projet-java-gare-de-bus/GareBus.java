package garebus;
import java.io.*;
/**
 *
 * @author ASUS
 */
public class GareBus {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        
        


    
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("-----------------------AGENCE D'EL JADIDA-----------------------");
        System.out.println("Ville de d�part:: EL JADIDA\n\n");
        System.out.println("   ");
    
      
       // declaration du varriable:
    String utl,mdp,ON,recherche,autrefois,choix;
    int t=0,y=1,z=0,fin=0,r=1;
    int disponible[] = new int[6];
    int ticketA[][] = new int [100][3];
    String ticketB[][] = new String[100][3];
    double ticketC[][] = new double [100][3];
    double payer[] = new double[20];
    double change[] = new double[20];
    
    for(int i=1;i<4;){
		System.out.print("Entrez votre nom : ");
		utl = in.readLine();
		System.out.print("Entrez votre mot de passe : ");
		mdp = in.readLine();
    

    for(int o=1; o<=5; o++){
    		disponible[o]=20;
  		}
    
    if(utl.equals("estsb") && mdp.equals("estsb")){
    	
    for(int x=1; x==1;){
    			// Tableau r�servation   de  billetterie:
    	System.out.println("-------------------------------------------------------");
    	System.out.println("|| R�servation   de  billetterie   **");
    	System.out.println("-------------------------------------------------------");
    	System.out.println("|| [1] Destination                                   ||");
    	System.out.println("|| [2] Passagers                                     ||");
    	System.out.println("|| [3] Facturation                                   ||");
    	System.out.println("|| [4] Vue                                           ||");
    	System.out.println("|| [5] Sortie                                        ||");
    	System.out.println("-------------------------------------------------------");
    	System.out.println("-------------------------------------------------------\n");
    	
    for(x=1; x==1;){
	System.out.print("Entrez votre choix: ");
	choix=in.readLine();
					//Tableau contient des information pour le ticket:
	if (choix.equals("1")){
	System.out.println("-------------------------------------------------------");
    	System.out.println("||   Destination   ||  Prix ||  Place ||");
    	System.out.println("-------------------------------------------------------");
	System.out.println("|| 1.)Safi         || 30DH  ||   "+disponible[1]+"   ||");
    	System.out.println("|| 2.)Casablanca   || 50DH  ||   "+disponible[2]+"   ||");
    	System.out.println("|| 3.)Oujda        || 180DH ||   "+disponible[3]+"   ||");
   	System.out.println("|| 4.)F�s          || 150DH ||   "+disponible[4]+"   ||");
    	System.out.println("|| 5.)T�touan      || 200DH ||   "+disponible[5]+"   ||");
    	System.out.println("-------------------------------------------------------");
	System.out.println("-------------------------------------------------------\n");
        System.out.println("Remise de 10% pour les �tudiants !!!\n");	
    	x=0;
		}
					
	else if (choix.equals("2")){
		int print=1;
					 	
	System.out.println("-------------------------------------------------------");
    	System.out.println("||   Destination   ||  Prix ||  Place ||");
    	System.out.println("-------------------------------------------------------");
	System.out.println("|| 1.)Safi         || 30DH  ||   "+disponible[1]+"   ||");
    	System.out.println("|| 2.)Casablanca   || 50DH  ||   "+disponible[2]+"   ||");
    	System.out.println("|| 3.)Oujda        || 180DH ||   "+disponible[3]+"   ||");
   	System.out.println("|| 4.)F�s          || 150DH ||   "+disponible[4]+"   ||");
    	System.out.println("|| 5.)T�touan      || 200DH ||   "+disponible[5]+"   ||");
    	System.out.println("-------------------------------------------------------");
	System.out.println("-------------------------------------------------------\n");
        System.out.println("Remise de 10% pour les �tudiants !!!\n");
    	if((disponible[1]==0)&&(disponible[2]==0)&&(disponible[3]==0)&&(disponible[4]==0)&&(disponible[5]==0)){
    	System.out.println("Desol�, Nous n'avons pas de places disponibles pour toutes les destinations  !");
    	x=0;
    						
    		}
    	else{
    	for(x=1; x==1;){
    	System.out.print("\nEntrez le nom du passager: ");
    	ticketB[z][0] = in.readLine();
	x=0;
	for(int l=0; l<z; l++){
   	if(ticketB[l][0].equalsIgnoreCase(ticketB[z][0])){
    	System.out.println("D�sol�, Le nom du passager a d�j� �t�s utilis�!!!");
    	x=1;
    							}
    						}
    					}
    					
    		
    	for(x=1; x==1;){
    	System.out.print("Entrez la destination [numero]: ");
    		t = Integer.parseInt(in.readLine());
    						
    		if(t<1 || t>5){
    		System.out.println("Entr�e invalide!!!");
    		x=1;
    						}
    		for(int k=1; k<=5; k++){
    		if(t==k){
    		if(disponible[t]==0){
    		System.out.println("D�sol�, Nous n'avons pas de place disponible!!");
    		x=1;
    		}
    		x=0;
    		}
    						}
    					}
    	String dest[] = { " ", "El jadida", "Casablanca", "Oujda", "F�s", "T�touan"};
    	double prix[] = { 0,30,50,150,180,200};
    		
    	ticketB[z][1] = dest[t];
    	ticketC[z][0] = prix[t];
    					
    	for(x=1; x==1;){
    System.out.print("Combien de passagers etes-vous ?: ");
    	ticketA[z][0] = Integer.parseInt(in.readLine());
    		
    	for(int j=1; j<=5; j++){
    	if(t==j){
    	print=1;
    	disponible[t] = disponible[t]-ticketA[z][0];
    							
    	if(disponible[t]<0){
    System.out.print("D�sol�, Nous avons pas de place disponible pour " +ticketA[z][0] +" persones\n");
    	disponible[t] = disponible[t]+ticketA[z][0];
    System.out.print("Nou avons seulement " +disponible[t] +" place disponible\n");
    	x=1;
    	print=0;
    						}
    	else{
    	x=0;
    	}
    	}
    	}
    		
    					}
    					
        for(x=1;x==1;){
    System.out.print("Combien de passagers ont une remise?: ");
        ticketA[z][1] = Integer.parseInt(in.readLine());
    					
    	if(ticketA[z][1]>ticketA[z][0]){
    						
    System.out.println("Entr�e invalide!!!");
    System.out.println("Non, Nombre du passagers sont seulement " +ticketA[z][0] +"!");
    	x=1;
    						}
    	else{
    	break;
    						}
    					}
    		
    		
    // Details du passagers  
    if(print==1){
   System.out.println("\n---------------------------------------");
   System.out.println("||        Details du passagers         ||");
   System.out.println("-----------------------------------------");
   System.out.println("Nom du passager: " + ticketB[z][0]);
   System.out.println("Destination du passager : " + ticketB[z][1]);
   System.out.println("Prix :  " + ticketC[z][0] +"DH");
   System.out.println("Nombre du passagers: " + ticketA[z][0]);
   System.out.println("Nombre du passagers avec remise: " + ticketA[z][1]);
   System.out.println("-----------------------------------------");
   System.out.println("-----------------------------------------\n");
   	ticketB[z][2]="0";
   	double remise=(ticketC[z][0]-(ticketC[z][0]*0.1))*ticketA[z][1];
   	ticketC[z][2]= ((ticketA[z][0]-ticketA[z][1])*ticketC[z][0])+remise;
   	x=0;
   			}
   	z++;
   			}
  		}
					
	else if (choix.equals("3")){
			          
			            
	for(x=1; x==1;){
			
    System.out.print("Entrez le nom du passager: ");
	recherche = in.readLine();
								
								
	int s=1;
	for(int b=0;b<z;b++){
	if(recherche.equalsIgnoreCase(ticketB[b][0])){
    System.out.println("-----------------------------------------");
    System.out.println("||        Details du passagers         ||");
    System.out.println("-----------------------------------------");
    System.out.println("Nom du passager: " + ticketB[b][0]);
    System.out.println("Destination du passager : " + ticketB[b][1]);
    System.out.println("Prix : " + ticketC[b][0] +"DH");
    System.out.println("Nombre du passagers: " + ticketA[b][0]);
    System.out.println("Nombre du passagers avec remise: " + ticketA[b][1]);
 		   				        
    System.out.println("-----------------------------------------");
    System.out.println("-----------------------------------------");
	s=0;
        x=0;
										
	if(ticketB[b][2].equals("x")){
    System.out.println("Le passagers est d�ja pay�!");
	x=0;
       }
	else{
 	ticketB[b][2]="x";
	   									
	  								
	for(x=1; x==1;){
    System.out.println("\nPrix total du passager: "+ticketC[b][2]+ "DH");
    System.out.print("Entrez le montant � payer : ");
    payer[b] = Double.parseDouble(in.readLine());
    change[b]=payer[b]-ticketC[b][2];
	    							
        if(change[b]<0){
    System.out.println("Entr�e invalide!");
       x=1;
	    				}
	else{
    System.out.println("Changement: "+change[b] +"DH");
    System.out.println("");
       x=0;
	    }
	   	}
		}
		}			
        }
	if (s==1){
    System.out.println("\nNom du passager introuvable!\n");
	for(int q=1; q==1;){
									
    System.out.print("Voulez-vous  continuer avec cette transaction? [O/N]: ");
	autrefois=in.readLine();
									
    if(autrefois.equalsIgnoreCase("o")){
	q=0;
	}
	else if (autrefois.equalsIgnoreCase("n")){
	q=0;
	x=0;
										
			}
        else{
    System.out.println("\n Entr�e invalide!\n");
			}
			}
			}	
			}
			            
		}
					
	else if (choix.equals("4")){
						
						
       for(int sx=1; sx<=3;){
    System.out.print("Rechercher le nom du passager: ");
    	recherche = in.readLine();
    		    
    	int s=1;
	for(x=0; x<=z; x++){
	if(recherche.equalsIgnoreCase(ticketB[x][0])){
   System.out.println("-----------------------------------------");
   System.out.println("||        Details du passagers         ||");
   System.out.println("-----------------------------------------");
   System.out.println("Nom du passager: " + ticketB[x][0]);
   System.out.println("Destination du passager  : " + ticketB[x][1]);
   System.out.println("Prix : " + ticketC[x][0]+"DH");
   System.out.println("Nombre du passagers : " + ticketA[x][0]);
   System.out.println("Nombre du passagers avec remise : " + ticketA[x][1]);
   System.out.println("Prix total : " + ticketC[x][2] +"DH");
   	if(ticketB[x][2].equals("x")){
   System.out.println("Payer: " +payer[x] +"DH");
   System.out.println("Changement: " +change[x]+"DH");
   System.out.println("Statut: Pay�");
   				}
  else{
    System.out.println("Statut: Impay�");
        }
    System.out.println("-----------------------------------------");
    System.out.println("-----------------------------------------");
    s=0;
    sx=4;
					}
					}	
						
						
if (s==1){
    System.out.println("Nom du passager introuvable!");
    sx++;}
						
				    	}
					}		
					
    else if(choix.equals("5")){
	fin=1;
	x=0;
    System.out.println("MERCI:)!");
					}
				
        else{
    System.out.println("Entr�e invalide!");
	x=1;
					}
    			}
    	
    for(y=1; y==1;){
    if(fin==1){
    	break;
    				}
    System.out.print("Voulez-vous une autre transaction? [O/N]: ");
    	ON = in.readLine();
    	
   	if (ON.equalsIgnoreCase("o")){
   	x=1;
   	y=0;
    				}
   	else if (ON.equalsIgnoreCase("n")){
   System.out.println("\nMERCI:)!!!");
   	break;
    				}
   	else{
   System.out.println("Entr�e invalide!!!");
   	y=1;
    				}
    			}
    		}
   	i=4;
    	}
    	else{
   System.out.println("\n Utilisateur ou mot de passe invalide!\n");
   	i++;
		}
	
    }
    
    }
    
    
}
    
    
