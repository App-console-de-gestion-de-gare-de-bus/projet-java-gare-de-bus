Application console pour la gestion d'une gare de bus
Le nom d'utilisateur: estsb
Le mot de passe : estsb

Cette application est devloppé par:
	-Chaimae Benlkharchouf
	-Doha Akdim
	-Laila Najah

Cette aplication nous permet de faire  des réservations des billets pour les passagers en entrant leurs informations et leurs choix.
Automatiquement l'application affiche et donne le prix total  avec une réduction pour les étudiants si il est disponible ainsi le statut de passager (payé ou non)
